from app import app, db
from app.models import Pet, Category, PhotoURLS, Tags

# flask shell
# db.session.query(Pet).all()
@app.shell_context_processor
def make_shell_context():
    return {'db': db, 'Pet': Pet, 'Category': Category, 'PhotoURLS': PhotoURLS, 'Tags' : Tags, 'Order' : Order, 'User' : User}
