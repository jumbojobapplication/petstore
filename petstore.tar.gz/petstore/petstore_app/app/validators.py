from flask import Response

def check_int(id):
    try:
        id = int(id)
        return id
    except:
        return False

def check_put(content):
    try:
        if not content.get('category') \
                or not content.get('name') \
                or not content.get('photoUrls') \
                or not content.get('tags') \
                or not content.get('status'):
            return False
    except:
        return True
    return True
