import dicttoxml
import datetime
from flask import render_template, flash, redirect, url_for, Response, request
from app import app
from app import app, db, validators, controller
from app.models import Pet, Category, PhotoURLS, Tags, Order, User

# do this:
# service apache2 stop
# in docker
# export FLASK_APP=petstore.py
# local
# export FLASK_APP=/home/craigw/Downloads/petstore/petstore_app/petstore.py
# sudo /home/craigw/.virtualenvs/petstore/bin/flask run  --host=0.0.0.0 --port=80
#
# @app.route('/')
# @app.route('/index')
# def index():
#     return "hello world"

@app.route('/pet/<id>', methods = ['GET'])
def pet(id):
    id = validators.check_int(id)
    if not id: return Response("Invalid ID supplied", status=400)

    pet = db.session.query(Pet).filter(Pet.id == id).one_or_none()
    if pet:
        xml = dicttoxml.dicttoxml(pet.to_json(), attr_type=False, custom_root='Pet')
        return xml
    else:
        return Response("Pet not found", status=404)

# Update with form data
@app.route('/pet/<id>', methods = ['POST'])
def pet_form(id):
    try:
        status = request.form.get('status')
        id     = request.form.get('id')
        name   = request.form.get('name')
    except:
        return Response("Invalid input", status=405)

    id = validators.check_int(id)
    if not id: return Response("Invalid ID supplied", status=400)

    pet = db.session.query(Pet).filter(Pet.id == id).one_or_none()

    pet.status = status
    pet.name = name
    db.session.add(pet)
    db.session.commit()

    if pet:
        xml = dicttoxml.dicttoxml(pet.to_json(), attr_type=False, custom_root='Pet')
        return xml
    else:
        return Response("Pet not found", status=404)

@app.route('/pet/<id>', methods = ['DELETE'])
def pet_delete(id):
    id = validators.check_int(id)
    if not id: return Response("Invalid ID supplied", status=400)

    pet = db.session.query(Pet).filter(Pet.id == id).one_or_none()
    if pet:
        db.session.delete(pet)
        db.session.commit()
        return Response("ok", status=200)
    else:
        return Response("Pet not found", status=400)

    return Response("Pet not found", status=400)

@app.route('/pet', methods = ['POST'])
def pet_post():
    try:
        content = request.json
        id = content.get('id')
    except:
        return Response("Validation exception", status=405)

    id = validators.check_int(id)
    if not id: return Response("Invalid ID supplied", status=400)

    ok = validators.check_put(content)
    if not ok: return Response("Validation exception", status=405)

    pet = controller.add_or_update_pet(content, id, "POST")

    xml = dicttoxml.dicttoxml(pet.to_json(), attr_type=False, custom_root='Pet')
    return xml

@app.route('/pet', methods = ['PUT'])
def pet_put():
    try:
        content = request.json
        id = content.get('id')
    except:
        return Response("Validation exception", status=405)

    id = validators.check_int(id)
    if not id: return Response("Invalid ID supplied", status=400)

    ok = validators.check_put(content)
    if not ok: return Response("Validation exception", status=405)

    pet = controller.add_or_update_pet(content, id, "PUT")

    if isinstance(pet, Pet):
        xml = dicttoxml.dicttoxml(pet.to_json(), attr_type=False, custom_root='Pet')
        return xml
    else:
        return pet

@app.route('/pet/findByStatus', methods = ['GET'])
def pet_find_by_status():
    # assuming this comes in as parameters as part of the url, i.e ..Status?available=1&sold=1
    # 127.0.0.1/pet/findByStatus?available=1
    try:
        statuses = request.args.keys()
        for status in statuses:
            if status not in ['available', 'pending','sold']:
                return Response("Invalid status value", status=400)
    except:
        return Response("Invalid status value", status=400)

    pets = db.session.query(Pet).filter(Pet.status.in_(statuses)).all()

    pets = [p.to_json() for p in pets]

    xml = dicttoxml.dicttoxml(pets, attr_type=False, custom_root='Pets')
    return xml

# Order / store
@app.route('/store/order', methods = ['POST'])
def order():
    try:
        content = request.json
        id       = int(content.get('id'))
    except:
        return Response("Invalid Order", status=400)
    order = db.session.query(Order).filter(Order.id == id).one_or_none()

    if order:
        # there is an order already in the syste
        return Response("Invalid Order", status=400)

    order = controller.add_or_update_store(content, id, "POST")

    xml = dicttoxml.dicttoxml(order.to_json(), attr_type=False, custom_root='Pets')
    return xml

@app.route('/store/order/<id>', methods = ['GET'])
def order_get(id):

    id = validators.check_int(id)
    if not id: return Response("Invalid ID supplied", status=400)

    order = db.session.query(Order).filter(Order.id == id).one_or_none()

    if not order:
        return Response("Order not found", status=404)

    xml = dicttoxml.dicttoxml(order.to_json(), attr_type=False, custom_root='Pets')
    return xml

@app.route('/store/order/<id>', methods = ['DELETE'])
def order_delete(id):

    id = validators.check_int(id)
    if not id: return Response("Invalid ID supplied", status=400)

    order = db.session.query(Order).filter(Order.id == id).one_or_none()

    if not order:
        return Response("Order not found", status=404)

    return Response("ok", status=200)

@app.route('/store/inventory', methods = ['GET'])
def order_inventory():
    # assuming this comes in as parameters as part of the url, i.e ..Status?available=1&sold=1
    try:
        statuses = request.args.keys()
        for status in statuses:
            if status not in ['placed', 'approved', 'delivered']:
                return Response("Invalid status value", status=400)
    except:
        return Response("Invalid status value", status=400)

    orders = db.session.query(Order).filter(Order.status.in_(statuses)).all()

    orders = [order.to_json() for order in orders]

    xml = dicttoxml.dicttoxml(orders, attr_type=False, custom_root='Orders')
    return xml

# user
@app.route('/user', methods = ['POST'])
def user_post():
    # How can a person be logged in and post a new user? dunno what to do here. leaving out the login thing.
    try:
        content = request.json
        id      = int(content.get('id'))
    except:
        return Response("Invalid Order", status=400)

    user = db.session.query(User).filter(User.id == id).one_or_none()

    if user:
        # there is an order already in the system
        return Response("Invalid User", status=400)

    user = controller.add_or_update_user(content, id, "POST")

    xml = dicttoxml.dicttoxml(user.to_json(), attr_type=False, custom_root='User')
    return xml

@app.route('/user/createWithArray', methods = ['POST'])
@app.route('/user/createWithList', methods = ['POST'])
def user_array():
    try:
        content = request.json
    except:
        return Response("Invalid Order", status=400)

    users = controller.add_or_update_user_with_array(content, id, "POST")

    if not users:
        return Response("Invalid Order", status=400)

    users = [user.to_json() for user in users]

    xml = dicttoxml.dicttoxml(users, attr_type=False, custom_root='Users')
    return xml

@app.route('/user/<username>', methods = ['GET'])
def user_get(username):
    try:
        username = str(username)
    except:
        return Response("Invalid username supplied", status=400)

    user = db.session.query(User).filter(User.username == username).one_or_none()

    if not user:
        # there is a user already in the system
        return Response("User not found", status=404)

    xml = dicttoxml.dicttoxml(user.to_json(), attr_type=False, custom_root='User')
    return xml

@app.route('/user/login', methods = ['GET'])
def user_login():
    #Since this is a get, are the values coming in as parameters? i guess so
    try:
        statuses = request.args.keys()
        for status in statuses:
            if status not in ['username', 'password']:
                return Response("Invalid username/password supplied", status=400)
        username = str(request.args.get('username'))
        password = str(request.args.get('password'))

        user = db.session.query(User) \
            .filter(User.username == username).one_or_none()
        user.rate_limit.increase_attempts()
    except:
        return Response("Invalid username/password supplied", status=400, headers=[('X-Rate-Limit', 30)])

    # 30 attempts / minute
    if user.rate_limit.attempts >= 30:
        return Response("Invalid username/password supplied", status=400)

    if user.password != password:
        return Response("Invalid username/password supplied", status=400)
    else:
        # logged in, 30 minutes
        user.userStatus = True
        db.session.commit()
        expiry = user.rate_limit.date + datetime.timedelta(minutes=30)
        headers = [
            ('X-Rate-Limit', 30),
            ('X-Expires-After', expiry.strftime("%Y-%m-%dT%H:%M:%S.%fZ"))
        ]
        return Response("ok", status=200)

@app.route('/user/logout', methods = ['GET'])
def user_logout():
    #Since there is no information here.. i guess parameter username is in the url
    try:
        statuses = request.args.keys()
        for status in statuses:
            if status not in ['username']:
                return Response("Invalid username supplied", status=400)
        username = str(request.args.get('username'))

        user = db.session.query(User) \
            .filter(User.username == username).one_or_none()

        if not user:
            return Response("Invalid username supplied", status=400)
    except:
        return Response("Invalid username supplied", status=400)

    # Log out
    user.userStatus = False
    db.session.commit()

    return Response("ok", status=200)

@app.route('/user/<username>', methods = ['PUT'])
def user_put(username):
    try:
        content = request.json
        username = str(username)
    except:
        return Response("Invalid username supplied", status=400)

    user = db.session.query(User).filter(User.username == username).one_or_none()

    if not user:
        # there is a user already in the system
        return Response("Invalid user supplied", status=400)
    if not user.userStatus:
        return Response("User not found", status=404)

    user = controller.add_or_update_user(content, id, "PUT")

    xml = dicttoxml.dicttoxml(user.to_json(), attr_type=False, custom_root='User')
    return xml

@app.route('/user/<username>', methods = ['DELETE'])
def user_delete(username):
    try:
        username = str(username)
    except:
        return Response("Invalid user supplied", status=400)

    user = db.session.query(User).filter(User.username == username).one_or_none()

    if not user:
        return Response("User not found", status=404)
    db.session.delete(user)
    db.session.commit()

    return Response("ok", status=200)

