from app import db

class Pet(db.Model):
    __tablename__ = 'pet'

    id            = db.Column(db.Integer, primary_key=True)
    name          = db.Column(db.String)
    status        = db.Column(db.String)

    categories = db.relationship("Category", backref=db.backref("pet"), cascade="all, delete-orphan")
    photo_urls = db.relationship("PhotoURLS", backref=db.backref("pet"), cascade="all, delete-orphan")
    tags       = db.relationship("Tags", backref=db.backref("pet"), cascade="all, delete-orphan")

class Category(db.Model):
    __tablename__ = 'category'

    id     = db.Column(db.Integer, primary_key=True)
    name   = db.Column(db.String)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    pet = db.relationship("Pet", backref=db.backref("categories"))

class PhotoURLS(db.Model):
    __tablename__ = 'photo_urls'

    id     = db.Column(db.Integer, primary_key=True)
    name   = db.Column(db.String)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    pet = db.relationship("Pet", backref=db.backref("photo_urls"))

class Tags(db.Model):
    __tablename__ = 'tags'

    id     = db.Column(db.Integer, primary_key=True)
    name   = db.Column(db.String)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    pet = db.relationship("Pet", backref=db.backref("tags"))