import datetime
from app import db

class Pet(db.Model):
    __tablename__ = 'pet'

    id            = db.Column(db.Integer, primary_key=True)
    name          = db.Column(db.String, unique=True)
    status        = db.Column(db.String)
    order_id      = db.Column(db.Integer, db.ForeignKey('order.petId', ondelete="cascade", onupdate="cascade"))

    category   = db.relationship("Category", backref=db.backref("pet"), cascade="all, delete-orphan", uselist=False)
    photo_urls = db.relationship("PhotoURLS", backref=db.backref("pet"), cascade="all, delete-orphan")
    tags       = db.relationship("Tags", backref=db.backref("pet"), cascade="all, delete-orphan")

    def to_json(self):
        # go to json first

        return {
            'id'       : self.id,
            'Category' : self.category.to_json(),
            'name'     : self.name,
            'photoUrl' : [i.to_json() for i in self.photo_urls],
            'tag'      : {
                            'Tag' : [i.to_json() for i in self.tags],
                         },
            'status'   : self.status
        }


class Category(db.Model):
    __tablename__ = 'category'

    id     = db.Column(db.Integer, primary_key=True)
    name   = db.Column(db.String)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    # pet = db.relationship("Pet", backref=db.backref("categories"))

    def to_json(self):
        return {
            'id' : self.id,
            'name' : self.name
        }


class PhotoURLS(db.Model):
    __tablename__ = 'photo_urls'

    id     = db.Column(db.Integer, primary_key=True)
    name   = db.Column(db.String)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    # pet = db.relationship("Pet", backref=db.backref("photo_urls"))

    def to_json(self):
        return {
            'id' : self.id,
            'name' : self.name
        }


class Tags(db.Model):
    __tablename__ = 'tags'

    id     = db.Column(db.Integer, primary_key=True)
    name   = db.Column(db.String)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    # pet = db.relationship("Pet", backref=db.backref("tags"))+

    def to_json(self):
        return {
            'id' : self.id,
            'name' : self.name
        }


class Order(db.Model):
    __tablename__ = 'order'

    id       = db.Column(db.Integer, primary_key=True)
    petId    = db.Column(db.Integer, db.ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"))
    quantity = db.Column(db.Integer)
    shipDate = db.Column(db.DateTime)
    status   = db.Column(db.String)
    complete = db.Column(db.Boolean)

    # pet = relationship("Pet", back_populates="tags")

    def to_json(self):
        return {
            'id' : self.id,
            'petId' : self.petId,
            'quantity' : self.quantity,
            'shipDate' : self.shipDate,
            'status' : self.status,
            'complete' : self.complete,
        }


class User(db.Model):
    __tablename__ = 'user'

    id         = db.Column(db.Integer, primary_key=True)
    username   = db.Column(db.String)
    firstName  = db.Column(db.String)
    lastName   = db.Column(db.String)
    email      = db.Column(db.String)
    password   = db.Column(db.String)
    phone      = db.Column(db.String)
    userStatus = db.Column(db.Integer)

    rate_limit = db.relationship("RateLimitUser", backref=db.backref("rate_limit_user"), uselist=False)

    def to_json(self):
        return {
            'id' : self.id,
            'username' : self.username,
            'firstName' : self.firstName,
            'lastName' : self.lastName,
            'email' : self.email,
            'password' : self.password,
            'phone' : self.phone,
            'userStatus' : self.userStatus,
        }

class RateLimitUser(db.Model):
    __tablename__ = 'rate_limit_user'

    id       = db.Column(db.Integer, primary_key=True)
    user_id  = db.Column(db.Integer, db.ForeignKey('user.id', ondelete="cascade", onupdate="cascade"))
    attempts = db.Column(db.Integer)
    date     = db.Column(db.DateTime)

    user = db.relationship("User", backref=db.backref("user"))

    def check_date(self):
        now = datetime.datetime.now()

        if (now - self.date).seconds > 60:
            self.attempts = 0
            self.date = now

    def increase_attempts(self):
        self.check_date()
        self.attempts += 1

    # user = relationship("user", back_populates="rate_limit")