import datetime
from app import db
from app.models import Pet, Category, PhotoURLS, Tags, Order, User, RateLimitUser

def add_or_update_pet(content, id, mode):
    category  = content.get('category')
    name      = content.get('name')
    photoUrls = content.get('photoUrls')
    tags      = content.get('tags')
    status    = content.get('status')

    pet = db.session.query(Pet).filter(Pet.id == id).one_or_none()

    if not pet:
        if mode == 'PUT':
            return Response("Pet not found", status=400)
        else:
            pet = Pet(
                id=id,
                name=name,
                status=status
            )
            db.session.add(pet)
    else:
        pet.id     = id
        pet.name   = name
        pet.status = status

    if mode == 'PUT':
        if pet.tags:
            for tag in pet.tags:
                db.session.delete(tag)
        if pet.photo_urls:
            for photo in pet.photo_urls:
                db.session.delete(photo)
        if pet.category:
            if pet.category.id == category.get('id'):
                pet.category.name == category.get('name')
        else:
            new_category = Category(
                id=category.get('id'),
                name=category.get('name'),
            )
            pet.category = new_category

        db.session.commit()

    if mode == 'POST':
        category_db = db.session.query(Category).filter(Category.id == category.get('id')).one_or_none()

        if category_db:
            category_db.name=category.get('name')
            db.session.add(category_db)
        else:
            new_category = Category(
                id=category.get('id'),
                name=category.get('name'),
                pet_id=pet.id
            )
            pet.category = new_category
            db.session.add(new_category)

    for photo_url in photoUrls:
        url = PhotoURLS(
            name=photo_url,
            pet=pet
        )
        db.session.add(url)

    for tag in tags:
        tag_db = db.session.query(Tags).filter(Tags.id == tag.get('id')).one_or_none()

        if tag_db:
            tag_db.id = tag.get('id')
            tag_db.name = tag.get('name')
            tag_db.pet = pet
        else:
            tag = Tags(
                id=tag.get('id'),
                name=tag.get('name'),
                pet=pet
            )
            db.session.add(tag)

    db.session.commit()

    return pet

def add_or_update_store(content, id, mode):
    # there is no update here for store
    try:
        petId    = content.get('petId')
        quantity = content.get('quantity')
        shipDate = content.get('shipDate')
        status   = content.get('status')
        complete = content.get('complete')

        # Time as "2019-09-24T05:41:34.551Z"
        shipDate = datetime.datetime.strptime("2019-09-24T05:41:34.551Z","%Y-%m-%dT%H:%M:%S.%fZ")

        if mode == 'POST':
            order = Order(
                id=id,
                petId=petId,
                quantity=quantity,
                shipDate=shipDate,
                status=status,
                complete=complete
            )
        db.session.add(order)
        db.session.commit()
        return order
    except:
        return None

def add_or_update_user(content, id, mode):
    try:
        username   = content.get('username')
        firstName  = content.get('firstName')
        lastName   = content.get('lastName')
        email      = content.get('email')
        password   = content.get('password')
        phone      = content.get('phone')
        userStatus = content.get('userStatus')

        if mode == 'POST':
            user = User(
                username=username,
                firstName=firstName,
                lastName=lastName,
                email=email,
                password=password,
                phone=phone,
                userStatus=userStatus
            )

            db.session.add(user)
            db.session.commit()
            rl = RateLimitUser(
                attempts=0,
                date=datetime.datetime.now(),
                user_id=user.id
            )
            db.session.add(rl)
            db.session.commit()

        if mode == 'PUT':
            user = db.session.query(User).filter(User.username == username).one_or_none()
            if not user:
                return None

            user.username   = username
            user.firstName  = firstName
            user.lastName   = lastName
            user.email      = email
            user.password   = password
            user.phone      = phone
            user.userStatus = userStatus

            db.session.add(user)
            db.session.commit()

        return user
    except:
        return None

def add_or_update_user_with_array(content, id, mode):
    # Check all content is ok or else none of it is
    try:
        temp_users = []
        for user in content:
            id         = int(user.get('id'))
            username   = user.get('username')
            firstName  = user.get('firstName')
            lastName   = user.get('lastName')
            email      = user.get('email')
            password   = user.get('password')
            phone      = user.get('phone')
            userStatus = user.get('userStatus')

            if mode == 'POST':
                user = User(
                    id=id,
                    username=username,
                    firstName=firstName,
                    lastName=lastName,
                    email=email,
                    password=password,
                    phone=phone,
                    userStatus=userStatus
                )
                temp_users.append(user)

        for user in temp_users:
            db.session.add(user)
            db.session.commit()

            rl = RateLimitUser(
                attempts=0,
                date=datetime.datetime.now(),
                user_id=user.id
            )
            db.session.add(rl)
            db.session.commit()
        return temp_users
    except:
        return None


