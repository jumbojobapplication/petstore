import sqlalchemy
from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

# engine = create_engine('sqlite:///petstore.db', echo=True)
engine = create_engine('sqlite:///./petstore.db')

Base = declarative_base()

class Pet(Base):
    __tablename__ = 'pet'

    id       = Column(Integer, primary_key=True)
    name     = Column(String, unique=True)
    status   = Column(String)
    order_id = Column(Integer, ForeignKey('order.petId', ondelete="cascade", onupdate="cascade"))

    categories = relationship("Category", back_populates="pet", cascade="all, delete-orphan")
    photo_urls = relationship("PhotoURLS", back_populates="pet", cascade="all, delete-orphan")
    tags       = relationship("Tags", back_populates="pet", cascade="all, delete-orphan")

    orders     = relationship("Order", back_populates="pet", cascade="all, delete-orphan")

class Category(Base):
    __tablename__ = 'category'

    id     = Column(Integer, primary_key=True)
    name   = Column(String)
    pet_id = Column(Integer, ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    pet = relationship("Pet", back_populates="categories")

class PhotoURLS(Base):
    __tablename__ = 'photo_urls'

    id     = Column(Integer, primary_key=True)
    name   = Column(String)
    pet_id = Column(Integer, ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    pet = relationship("Pet", back_populates="photo_urls")

class Tags(Base):
    __tablename__ = 'tags'

    id     = Column(Integer, primary_key=True)
    name   = Column(String)
    pet_id = Column(Integer, ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"), nullable=False)

    pet = relationship("Pet", back_populates="tags")


class Order(Base):
    __tablename__ = 'order'

    id       = Column(Integer, primary_key=True)
    petId    = Column(Integer, ForeignKey('pet.id', ondelete="cascade", onupdate="cascade"))
    quantity = Column(Integer)
    shipDate = Column(DateTime)
    status   = Column(String)
    complete = Column(Boolean)

    pet = relationship("Pet", back_populates="tags")


class User(Base):
    __tablename__ = 'user'

    id         = Column(Integer, primary_key=True)
    username   = Column(String)
    firstName  = Column(String)
    lastName   = Column(String)
    email      = Column(String)
    password   = Column(String)
    phone      = Column(String)
    userStatus = Column(Integer)

    rate_limit = relationship("RateLimitUser", back_populates="user", cascade="all, delete-orphan")


class RateLimitUser(Base):
    __tablename__ = 'rate_limit_user'

    id       = Column(Integer, primary_key=True)
    user_id  = Column(Integer, ForeignKey('user.id', ondelete="cascade", onupdate="cascade"))
    attempts = Column(Integer)
    date     = Column(DateTime)

    user = relationship("User", back_populates="rate_limit")



Base.metadata.create_all(engine)

## Turn pragma ON
def _fk_pragma_on_connect(dbapi_con, con_record):
    dbapi_con.execute('pragma foreign_keys=ON')

from sqlalchemy import event
event.listen(engine, 'connect', _fk_pragma_on_connect)
### Turn pragma ON
SessionMaker = sessionmaker(bind=engine)
session = SessionMaker()


#
# p = Pet(
#     name="Steve",
#     status="available"
# )
#
# c = Category(
#     name="staffy",
#     pet=p
# )
#
# pu = PhotoURLS(
#     name = "https://images.dog.ceo/breeds/spaniel-cocker/n02102318_8666.jpg",
#     pet=p
# )
#
# t = Tags(
#     name="Steve tag",
#     pet=p
# )
#
# session.add(p)
# session.add(c)
# session.add(pu)
# session.add(t)
# session.commit()
# session.close()